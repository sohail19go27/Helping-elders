<?php
$username = $_POST['n'];
$password = $_POST['p'];

echo "$username" . "<br>";
echo "$password";














?>